package view;

import javax.swing.*;
import java.awt.*;

public class CalculatorView extends JFrame {
    private final JTextField display = new JTextField();
    private final String[] buttonLabels = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "", "0", "", "+",
            "C", "CE", "←", "="
    };
    private final JButton[] buttons = new JButton[buttonLabels.length];

    public CalculatorView() {
        setTitle("Calculator");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        display.setFont(new Font("Arial", Font.BOLD, 28));
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 4, 5, 5));

        for (int i = 0; i < buttonLabels.length; i++) {
            buttons[i] = new JButton(buttonLabels[i]);
            buttons[i].setFont(new Font("Arial", Font.BOLD, 22));
            panel.add(buttons[i]);
        }

        setLayout(new BorderLayout());
        add(display, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }

    public JTextField getDisplay() {
        return display;
    }

    public JButton[] getButtons() {
        return buttons;
    }

    public String[] getButtonLabels() {
        return buttonLabels;
    }
}