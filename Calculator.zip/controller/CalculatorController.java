package controller;

import model.CalculatorModel;
import view.CalculatorView;

import javax.swing.*;

public class CalculatorController {
    private final CalculatorModel model;
    private final CalculatorView view;
    private boolean newNumber = true;

    public CalculatorController(CalculatorModel model, CalculatorView view) {
        this.model = model;
        this.view = view;
        initController();
    }

    private void initController() {
        JButton[] buttons = view.getButtons();
        String[] labels = view.getButtonLabels();

        for (int i = 0; i < buttons.length; i++) {
            String value = labels[i];
            buttons[i].addActionListener(e -> handleButton(value));
        }
    }

    private void handleButton(String value) {
        JTextField display = view.getDisplay();

        switch (value) {
            case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" -> {
                if (newNumber) {
                    display.setText(value);
                    newNumber = false;
                } else {
                    display.setText(display.getText() + value);
                }
            }
            case "+", "-", "*", "/" -> {
                double current = getDisplayNumber();
                model.setFirstNumber(current);
                model.setOperator(value);
                newNumber = true;
            }
            case "=" -> {
                double second = getDisplayNumber();
                double result = model.calculate(second);
                display.setText(String.valueOf(result));
                newNumber = true;
            }
            case "C" -> {
                model.clear();
                display.setText("");
                newNumber = true;
            }
            case "CE" -> {
                display.setText("");
                newNumber = true;
            }
            case "←" -> {
                String text = display.getText();
                if (!text.isEmpty()) {
                    display.setText(text.substring(0, text.length() - 1));
                }
            }
        }
    }

    private double getDisplayNumber() {
        String text = view.getDisplay().getText();

        if (text.isEmpty()) {
            return 0;
        }

        return Double.parseDouble(text);
    }
}