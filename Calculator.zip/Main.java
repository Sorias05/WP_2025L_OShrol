import model.CalculatorModel;
import view.CalculatorView;
import controller.CalculatorController;

void main() {
    CalculatorModel model = new CalculatorModel();
    CalculatorView view = new CalculatorView();
    new CalculatorController(model, view);
}
