package model;

public class CalculatorModel {
    private double firstNumber = 0;
    private String operator = "";

    public void setFirstNumber(double number) {
        firstNumber = number;
    }

    public void setOperator(String op) {
        operator = op;
    }

    public double calculate(double secondNumber) {
        return switch (operator) {
            case "+" -> firstNumber + secondNumber;
            case "-" -> firstNumber - secondNumber;
            case "*" -> firstNumber * secondNumber;
            case "/" -> {
                if (secondNumber == 0) {
                    yield 0;
                }
                yield firstNumber / secondNumber;
            }
            default -> secondNumber;
        };
    }

    public void clear() {
        firstNumber = 0;
        operator = "";
    }
}