public abstract class AbstractMazeFactory {
    public abstract Room makeRoom(int x, int y, int number);

    public abstract Wall makeWall(int x, int y, Directions direction);

    public abstract Door makeDoor(Room r1, Room r2);
}