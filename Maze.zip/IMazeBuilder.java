public interface IMazeBuilder {
    void buildRoom(int number, int x, int y);

    void buildDoor(int room1, int room2);

    Maze getMaze();
}
