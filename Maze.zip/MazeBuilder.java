import java.awt.*;

public class MazeBuilder implements IMazeBuilder {
    private Maze maze;
    private AbstractMazeFactory factory;

    public MazeBuilder(AbstractMazeFactory factory) {
        maze = new Maze();
        this.factory = factory;
    }

    @Override
    public void buildRoom(int number, int x, int y) {
        if (maze.getRoom(number) != null) return;

        Room room = factory.makeRoom(x, y, number);
        room.setSite(Directions.NORTH, factory.makeWall(x, y, Directions.NORTH));
        room.setSite(Directions.SOUTH, factory.makeWall(x, y, Directions.SOUTH));
        room.setSite(Directions.WEST, factory.makeWall(x, y, Directions.WEST));
        room.setSite(Directions.EAST, factory.makeWall(x, y, Directions.EAST));
        maze.addRoom(room);
    }

    @Override
    public void buildDoor(int room1, int room2) {
        Room r1 = maze.getRoom(room1);
        Room r2 = maze.getRoom(room2);

        if (r1 != null && r2 != null) {
            factory.makeDoor(r1, r2);
        }
    }

    @Override
    public Maze getMaze() {
        return maze;
    }
}