import java.awt.*;

public class MazeFactory extends AbstractMazeFactory {
    @Override
    public Room makeRoom(int x, int y, int number) {
        return new Room(x, y, number);
    }

    @Override
    public Wall makeWall(int x, int y, Directions direction) {
        return new Wall(x, y, direction, Color.BLACK);
    }

    @Override
    public Door makeDoor(Room r1, Room r2) {
        return new Door(r1, r2, Color.RED);
    }
}