import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MazeApp extends JFrame {
    private JMyPanel panel; // panel, na którym rysujemy labirynt
    private Image image; // obiekt, na którym rysujemy labirynt

    public MazeApp() {
        setSize(800, 600);
        panel = new JMyPanel();
        setDefaultCloseOperation(EXIT_ON_CLOSE);  // określamy sposób zamykania okna
        setLayout( new BorderLayout() ); //
        JPanel panelButtons = new JPanel();
        panelButtons.setLayout(new GridLayout(1, 1));
        JButton button = new JButton("Draw");
        button.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MazeFactory factory = new MazeFactory();
                MazeBuilder builder = new MazeBuilder(factory);
                Maze maze = drawMaze(builder);
                Image image = panel.getImage();
                maze.draw(image);
                panel.repaint();
                // drawMaze2(400, 100);
            }
        });
        panelButtons.add(button);
        add(panelButtons, BorderLayout.NORTH);

        add(panel, BorderLayout.CENTER);
    }

    public Maze drawMaze(MazeBuilder builder) {
        int L = MapSite.L;
        int x = 200;
        int y = 200;
        builder.buildRoom(1, x, y);
        builder.buildRoom(2, x, y - L);
        builder.buildRoom(3, x, y + L);
        builder.buildRoom(4, x + L, y);
        builder.buildRoom(5, x + 2 * L, y);
        builder.buildRoom(6, x + 2 * L, y - L);
        builder.buildRoom(7, x + 2 * L, y + L);
        builder.buildRoom(8, x + 3 * L, y);

        builder.buildDoor(1, 2);
        builder.buildDoor(1, 3);
        builder.buildDoor(1, 4);
        builder.buildDoor(4, 5);
        builder.buildDoor(5, 6);
        builder.buildDoor(5, 7);
        builder.buildDoor(5, 8);

        return builder.getMaze();
    };

    /**
     * Testowanie klas Wall, Door, Room
     * @param x
     * @param y
     */
    public void drawMaze2(int x, int y) {
        image = panel.getImage();
        Graphics g = image.getGraphics();

        Wall w1 = new Wall(x, y, Directions.NORTH, Color.GREEN);
        w1.draw(image);
        Color color = Color.BLACK;
        int nr = 1;
        Room r1 = new Room(x, y, nr++);
        r1.setSite(Directions.WEST, w1);
        r1.setSite(Directions.NORTH, new Wall(x, y, Directions.NORTH, color));
        r1.setSite(Directions.SOUTH, new Wall(x, y, Directions.NORTH, color));
        r1.setSite(Directions.EAST, new Wall(x, y, Directions.NORTH, color));

        Room r2 = new Room(x, y - MapSite.L, nr++);
        r2.setSite(Directions.NORTH, new Wall(x, y, Directions.NORTH, color));
        r2.setSite(Directions.EAST, new Wall(x, y, Directions.NORTH, color));
        r2.setSite(Directions.SOUTH, new Wall(x, y, Directions.NORTH, color));
        r2.setSite(Directions.WEST, new Wall(x, y, Directions.NORTH, color));

        Room r3 = new Room(x, y + MapSite.L, nr++);
        r3.setSite(Directions.NORTH, new Wall(x, y, Directions.NORTH, color));
        r3.setSite(Directions.EAST, new Wall(x, y, Directions.NORTH, color));
        r3.setSite(Directions.SOUTH, new Wall(x, y, Directions.NORTH, color));
        r3.setSite(Directions.WEST, new Wall(x, y, Directions.NORTH, color));

        Room r4 = new Room(x + MapSite.L, y, nr++);
        r4.setSite(Directions.NORTH, new Wall(x, y, Directions.NORTH, color));
        r4.setSite(Directions.EAST, new Wall(x, y, Directions.NORTH, color));
        r4.setSite(Directions.SOUTH, new Wall(x, y, Directions.NORTH, color));
        r4.setSite(Directions.WEST, new Wall(x, y, Directions.NORTH, color));

        Room r5 = new Room(x + 2 * MapSite.L, y, nr++);
        r5.setSite(Directions.NORTH, new Wall(x, y, Directions.NORTH, color));
        r5.setSite(Directions.EAST, new Wall(x, y, Directions.NORTH, color));
        r5.setSite(Directions.SOUTH, new Wall(x, y, Directions.NORTH, color));
        r5.setSite(Directions.WEST, new Wall(x, y, Directions.NORTH, color));

        Room r6 = new Room(x + 2 * MapSite.L, y - MapSite.L, nr++);
        r6.setSite(Directions.NORTH, new Wall(x, y, Directions.NORTH, color));
        r6.setSite(Directions.EAST, new Wall(x, y, Directions.NORTH, color));
        r6.setSite(Directions.SOUTH, new Wall(x, y, Directions.NORTH, color));
        r6.setSite(Directions.WEST, new Wall(x, y, Directions.NORTH, color));

        Room r7 = new Room(x + 2 * MapSite.L, y + MapSite.L, nr++);
        r7.setSite(Directions.NORTH, new Wall(x, y, Directions.NORTH, color));
        r7.setSite(Directions.EAST, new Wall(x, y, Directions.NORTH, color));
        r7.setSite(Directions.SOUTH, new Wall(x, y, Directions.NORTH, color));
        r7.setSite(Directions.WEST, new Wall(x, y, Directions.NORTH, color));

        Room r8 = new Room(x + 3 * MapSite.L, y, nr++);
        r8.setSite(Directions.NORTH, new Wall(x, y, Directions.NORTH, color));
        r8.setSite(Directions.EAST, new Wall(x, y, Directions.NORTH, color));
        r8.setSite(Directions.SOUTH, new Wall(x, y, Directions.NORTH, color));
        r8.setSite(Directions.WEST, new Wall(x, y, Directions.NORTH, color));

        Door d_1_2 = new Door(r1, r2, Color.RED);
        Door d_1_3 = new Door(r1, r3, Color.RED);
        Door d_1_4 = new Door(r1, r4, Color.RED);
        Door d_4_5 = new Door(r4, r5, Color.RED);
        Door d_5_6 = new Door(r5, r6, Color.RED);
        Door d_5_7 = new Door(r5, r7, Color.RED);
        Door d_5_8 = new Door(r5, r8, Color.RED);

        r1.draw(image);
        r2.draw(image);
        r3.draw(image);
        r4.draw(image);
        r5.draw(image);
        r6.draw(image);
        r7.draw(image);
        r8.draw(image);
        //d12.draw(image);

        panel.repaint();   // odrysowanie obrazu na panelu
    }


    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MazeApp().setVisible(true);  // tworzymy i wyświetlamy aplikację na ekranie
            }
        });
    }
}